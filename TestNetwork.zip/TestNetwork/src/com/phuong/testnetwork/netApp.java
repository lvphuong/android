package com.phuong.testnetwork;

import org.json.*;

public class netApp {
	public static String Login(String username, String password)
	{
		String LOGIN_URL="http://hangquan.net/mobilogin.php";
		String response = "";
		String tokenKey = "";
		try {
		    response = HttpUtils.urlContentPost(LOGIN_URL, "Username",username,"Passwd",password);
		} catch (Exception e) {
		    e.printStackTrace();
		}
		
		try {
	        JSONObject json= (JSONObject) new JSONTokener(response).nextValue();
	        JSONObject json2 = json.getJSONObject("result");
	        tokenKey = (String) json2.get("tokenKey");
	    }
	    catch (JSONException e) {
	        e.printStackTrace();
	    }

		return tokenKey;
	}
}

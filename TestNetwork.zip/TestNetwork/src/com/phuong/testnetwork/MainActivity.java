package com.phuong.testnetwork;

import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
import android.widget.TextView;

import com.phuong.testnetwork.HttpUtils;
import com.phuong.testnetwork.NetClient;

public class MainActivity extends Activity {
	
    @TargetApi(9)
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        StrictMode.ThreadPolicy policy = new StrictMode.
        		ThreadPolicy.Builder().permitAll().build();
        		StrictMode.setThreadPolicy(policy);
        		
        //Button loginButton = 
        //        (Button)findViewById(R.id.btnLogin);
        //loginButton.setOnClickListener(new btnLoginClick());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    public void btnLogin_Click(View clickedButton) {
    	String response = "";
    	
    	TextView txtUsername = (TextView)findViewById(R.id.txtUsername); 
    	TextView txtPassword = (TextView)findViewById(R.id.txtPassword);
    	
    	String _username = txtUsername.getText().toString();
    	String _password = txtPassword.getText().toString();
    	
    	response = netApp.Login(_username, _password);
    	    	
        Toast tempMessage =
                Toast.makeText(MainActivity.this, 
                		response, 
                               Toast.LENGTH_SHORT);
        tempMessage.show();
    }
    
    private class btnLoginClick implements OnClickListener {
        /** Creates a Toast (temporary message) when button is pressed. */
        @Override
        public void onClick(View v) {
        	TextView txtUsername = (TextView)findViewById(R.id.txtUsername); 
        	TextView txtPassword = (TextView)findViewById(R.id.txtPassword);
        	
        	String _username = txtUsername.getText().toString();
        	String _password = txtPassword.getText().toString();
        	
        	
        	/*
        	String LOGIN_URL="https://www.google.com/analytics";        	
        	NetClient client = new NetClient(LOGIN_URL);
        	client.AddParam("accountType", "GOOGLE");
        	client.AddParam("source", "tboda-widgalytics-0.1");
        	client.AddParam("Email", _username);
        	client.AddParam("Passwd", _password);
        	client.AddParam("service", "analytics");
        	client.AddHeader("GData-Version", "2");
        	
        	String LOGIN_URL="http://hangquan.net/mobilogin.php";
        	NetClient client = new NetClient(LOGIN_URL);
        	client.AddParam("Username", _username);
        	client.AddParam("Passwd", _password);
        	client.AddHeader("Content-Type", "text/html; charset=utf-8" );
        	try {
        	    client.Execute(NetClient.RequestMethod.POST);
        	} catch (Exception e) {
        	    e.printStackTrace();
        	}

        	String response = client.getResponse();

  */      	

        	String response = netApp.Login(_username, _password);
        	
            Toast tempMessage =
                    Toast.makeText(MainActivity.this, 
                    		response, 
                                   Toast.LENGTH_SHORT);
            tempMessage.show();
        }
    }
}

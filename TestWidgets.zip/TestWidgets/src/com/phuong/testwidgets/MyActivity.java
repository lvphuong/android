package com.phuong.testwidgets;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.RadioButton;
import android.widget.Toast;
import android.widget.ImageView;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class MyActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        RadioButton r1 = 
                (RadioButton)findViewById(R.id.radio0);
        RadioButton r2 = 
                (RadioButton)findViewById(R.id.radio1);
        RadioButton r3 = 
                (RadioButton)findViewById(R.id.radio2);
        r1.setOnClickListener(new ImgSetter(R.drawable.heart));
        r2.setOnClickListener(new ImgSetter(R.drawable.honey));
        r3.setOnClickListener(new ImgSetter(R.drawable.girl));
        
        CheckBox chkIos = (CheckBox) findViewById(R.id.checkBox1);        
    	chkIos.setOnCheckedChangeListener(new onChecked());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_my, menu);
        return true;
    }
            
    
    public void showButtonText(View clickedButton) { 
    	String greetingText = getString(R.string.apple);
        Toast tempMessage =
                Toast.makeText(this, 
                               greetingText, 
                               Toast.LENGTH_SHORT);
        tempMessage.show();
    }

    public class onChecked implements OnCheckedChangeListener  {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) { 
  	    	if (isChecked) {
  				TextView tv = (TextView) findViewById(R.id.textView2);
  				tv.setText(R.string.haha);
  				//setContentView(tv);
  			}
  	    	else
  	    	{
  				TextView tv = (TextView) findViewById(R.id.textView2);
  				tv.setText("...");
  				//setContentView(tv);
  			}
        }
    }
    
    private class ImgSetter implements OnClickListener {
        private int imgId;
        
        /** Constructs a ColorSetter event handler that stores
         *  the color. The onClick method will use the color to call
         *  back to setRegionColor method in the outer class.
         */
        public ImgSetter(int Id) {
            this.imgId = Id;
        }

        /** Calls back to the outer class to set the color of View at the bottom. */
        @Override
        public void onClick(View v) {
        	ImageView img = (ImageView) findViewById(R.id.imageView1);
        	img.setImageResource(imgId);
        }
    }
}
